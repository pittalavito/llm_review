## Molcule augmentations
__Associated repository for "Chemical Language Models Has Problems with Chemistry: A Case Study on Molecule Captioning Task"__
<br>
There are data and examples of code for experiments of the paper.<br>
<br>
Augmented datasets and original test you can find in "data" folder. Script for augmentations, example of usage and models evaluation are provided in the folder "code".<br>
<br>
